#!/bin/bash

# Copyright (c) MONAI Consortium
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

curr_dir="$(pwd)"
my_dir="$(dirname "$(readlink -f "$0")")"

echo "Installing requirements..."
sh $my_dir/requirements.sh

echo "This build includes the Image Redactor Extension by Emanuele Rinaldi <emanuele.rinaldi@databricks.com>"
echo "Licensed under Databricks License Agreement - see extensions/image-redactor/LICENSE"

install_dir=${1:-$my_dir/../../monailabel/endpoints/static/ohif}

echo "Current Dir: ${curr_dir}"
echo "My Dir: ${my_dir}"
echo "Installing OHIF at: ${install_dir}"

cd ${my_dir}
rm -rf Viewers
git clone https://github.com/OHIF/Viewers.git
cd Viewers
git checkout v3.11.1

#cp -r ../extensions/monai-label extensions/
#cp -r ../modes/monai-label modes/monai-label
cd extensions
ln -s ../../extensions/monai-label monai-label
cd ..

cd modes
ln -s ../../modes/monai-label monai-label
cd ..

# Install Image Redactor Extension
echo "Installing Image Redactor Extension..."
cd extensions
ln -s ${curr_dir}/../plugins/ohifv3/extensions/image-redactor image-redactor
cd ..

cd modes
ln -s ${curr_dir}/../plugins/ohifv3/modes/redaction-viewer redaction-viewer
cd ..

# Apply extensions patch to register monai-label and image-redactor in pluginConfig.json
echo "Applying extensions patch (registers monai-label and image-redactor)..."
git apply ${curr_dir}/../plugins/ohifv3/extensions.patch

cp ${curr_dir}/../plugins/ohifv3/config/databricks.js platform/app/public/config/databricks.js

#copy Databricks Pixels integration
echo "Installing Databricks Integration"
mkdir ./extensions/default/src/DatabricksPixelsDicom/
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/index.js ./extensions/default/src/DatabricksPixelsDicom/index.js
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/utils.js ./extensions/default/src/DatabricksPixelsDicom/utils.js
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/fixMultipart.ts ./extensions/default/src/DatabricksPixelsDicom/fixMultipart.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/StaticWadoClient.ts ./extensions/default/src/DatabricksPixelsDicom/StaticWadoClient.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/findIndexOfString.ts ./extensions/default/src/DatabricksPixelsDicom/findIndexOfString.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/getDataSourcesModule.js ./extensions/default/src/getDataSourcesModule.js
cp ${curr_dir}/../plugins/ohifv3/extensions/cornerstone-dicom-seg/src/commandsModule.ts ./extensions/cornerstone-dicom-seg/src/commandsModule.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/dicom-microscopy/src/utils/dicomWebClient.ts ./extensions/dicom-microscopy/src/utils/dicomWebClient.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/multiframeImageLoader.js ./extensions/default/src/DatabricksPixelsDicom/multiframeImageLoader.js

# Copy new files and apply Viewers patches for VLM Analyzer
cp ${curr_dir}/../plugins/ohifv3/extensions/cornerstone/src/utils/CornerstoneVLMViewportForm.tsx extensions/cornerstone/src/utils/CornerstoneVLMViewportForm.tsx
cp ${curr_dir}/../plugins/ohifv3/platform/ui-next/src/components/Icons/Sources/MagicWandIcon.tsx platform/ui-next/src/components/Icons/Sources/MagicWandIcon.tsx
 
git apply --reject --whitespace=fix ${curr_dir}/../viewers_extensions_cornerstone_src_commandsModule.ts.patch
git apply --reject --whitespace=fix ${curr_dir}/../viewers_extensions_cornerstone_src_index.tsx.patch
git apply --reject --whitespace=fix ${curr_dir}/../viewers_modes_longitudinal_src_index.ts.patch
git apply --reject --whitespace=fix ${curr_dir}/../viewers_modes_longitudinal_src_toolbarButtons.ts.patch
git apply --reject --whitespace=fix ${curr_dir}/../viewers_platform_ui-next_src_components_Icons_Icons.tsx.patch


yarn config set workspaces-experimental true
yarn install
yarn run cli list

#patching dicom-microscopy
sed -i.bak 's/await window.browserImportFunction(/await window.browserImportFunction("."+/g' ./platform/app/.webpack/writePluginImportsFile.js && rm ./platform/app/.webpack/writePluginImportsFile.js.bak

APP_CONFIG=config/databricks.js PUBLIC_URL=./ QUICK_BUILD=true yarn run build

rm -rf ${install_dir}
cp -r platform/app/dist/ ${install_dir}
echo "Copied OHIF to ${install_dir}"

if [ "$local" = "TRUE" ]; then
    echo "Building OHIF locally"
else
    rm -rf Viewers
    find .  -type d -name "node_modules" -exec rm -rf "{}" +
fi

echo "Patching index.html"
cd ${install_dir}
sed -i.bak 's/app-config.js/app-config-custom.js/g' index.html && rm index.html.bak
echo "OHIF for databricks created"

echo ""
echo "✅ Image Redactor Extension successfully integrated!"
echo "   - Extension: image-redactor"
echo "   - Mode: redaction-viewer" 
echo "   - Author: Emanuele Rinaldi <emanuele.rinaldi@databricks.com>"
echo "   - License: Databricks License Agreement"
echo ""
echo "🎯 Features available:"
echo "   - Manual rectangle drawing for redaction areas"
echo "   - Multiple area selection before applying redaction"
echo "   - Pixel burning (permanent redaction)"
echo "   - Undo functionality"
echo "   - Export redacted images as PNG"
echo ""
echo "📖 Usage: Select 'Redaction Viewer' mode in OHIF to access redaction tools"
echo ""

cd ${curr_dir}
