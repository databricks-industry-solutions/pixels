#!/bin/bash

# Copyright (c) MONAI Consortium
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# OHIF v3.13.2 requires Node >= 24 and pnpm >= 11.
NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)"
if [ "${NODE_MAJOR}" -lt 24 ]; then
  echo "WARNING: Node.js >= 24 required for OHIF v3.13.2 (found $(node -v 2>/dev/null || echo 'none'))."
  echo "         Install/activate Node 24 before building (e.g. nvm install 24 && nvm use 24)."
fi

if command -v pnpm >/dev/null 2>&1; then
  echo "pnpm is already installed ($(pnpm -v 2>/dev/null || echo unknown))"
elif command -v corepack >/dev/null 2>&1; then
  echo "Enabling pnpm via corepack..."
  corepack enable
  corepack prepare pnpm@11.5.2 --activate
else
  echo "ERROR: pnpm not found and corepack unavailable. Install Node >= 24 (includes corepack) or pnpm >= 11."
  exit 1
fi

if which nginx >/dev/null; then
  echo "nginx is already installed"
else
  if command -v apt-get >/dev/null 2>&1; then
    apt-get install nginx -y
  else
    echo "nginx not installed (skipping apt install on non-Debian host)"
  fi
fi
