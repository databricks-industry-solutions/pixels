/*
Copyright (c) MONAI Consortium
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at
    http://www.apache.org/licenses/LICENSE-2.0
Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

import React, { useRef } from 'react';
import { Button } from '@ohif/ui-next';
import OptionsForm from './actions/OptionsForm';

type OptionsActionId = 'save' | 'cancel' | 'reset';

type OptionsDialogBodyProps = {
  hide: () => void;
  config: any;
  info: any;
  callback: (options: any, actionId: OptionsActionId) => void;
};

const OptionsDialogBody: React.FC<OptionsDialogBodyProps> = ({
  hide,
  config,
  info,
  callback,
}) => {
  const optionsRef = useRef<OptionsForm | null>(null);

  const handleSave = () => {
    const current = (optionsRef.current as any)?.state?.config ?? {};
    callback(current, 'save');
    hide();
  };

  const handleCancel = () => {
    callback({}, 'cancel');
    hide();
  };

  const handleReset = () => {
    (optionsRef.current as any)?.onReset?.();
  };

  return (
    <div className="optionsDialog" style={{ width: '100%' }}>
      <OptionsForm
        ref={optionsRef as any}
        config={config}
        info={info}
      />
      <div
        style={{
          marginTop: '12px',
          display: 'flex',
          justifyContent: 'flex-end',
          gap: '8px',
        }}
      >
        <Button
          variant="secondary"
          onClick={handleReset}
        >
          Reset
        </Button>
        <Button
          variant="secondary"
          onClick={handleCancel}
        >
          Cancel
        </Button>
        <Button
          variant="default"
          onClick={handleSave}
        >
          Confirm
        </Button>
      </div>
    </div>
  );
};

function optionsInputDialog(uiDialogService, config, info, callback) {
  const dialogId = 'monai-label-options';
  uiDialogService.show({
    id: dialogId,
    title: 'Options / Configurations',
    content: OptionsDialogBody,
    shouldCloseOnEsc: true,
    containerClassName: 'max-w-3xl w-[90vw]',
    contentProps: {
      config,
      info,
      callback,
    },
  });
}

export default optionsInputDialog;
