#!/bin/bash

# Copyright (c) MONAI Consortium
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#     http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

curr_dir="$(pwd)"
my_dir="$(dirname "$(readlink -f "$0")")"

echo "Installing requirements..."
sh $my_dir/requirements.sh

echo "This build includes the Image Redactor Extension by Emanuele Rinaldi <emanuele.rinaldi@databricks.com>"
echo "Licensed under Databricks License Agreement - see extensions/image-redactor/LICENSE"

install_dir=${1:-$my_dir/../../monailabel/endpoints/static/ohif}

echo "Current Dir: ${curr_dir}"
echo "My Dir: ${my_dir}"
echo "Installing OHIF at: ${install_dir}"

cd ${my_dir}
rm -rf Viewers
git clone https://github.com/OHIF/Viewers.git
cd Viewers
git checkout v3.13.2

# OHIF v3.13.2 uses pnpm workspaces (yarn/lerna/bun are gone). Keep these
# removals as a no-op safety net if an older checkout is reused.
rm -f bun.lock bunfig.toml bunfig.update-lockfile.toml yarn.lock

# Copy custom extensions/modes into the Viewers tree (do not symlink).
# Symlinks resolve to realpaths outside Viewers/, and Rspack then walks
# node_modules from that outside path — missing the hoisted install under
# Viewers/node_modules (nrrd-js, nifti-reader-js, etc.).
cd extensions
rm -rf monai-label
cp -a ../../extensions/monai-label monai-label
cd ..

cd modes
rm -rf monai-label
cp -a ../../modes/monai-label monai-label
cd ..

# Install Image Redactor Extension
echo "Installing Image Redactor Extension..."
cd extensions
rm -rf image-redactor
cp -a ${curr_dir}/../plugins/ohifv3/extensions/image-redactor image-redactor
cd ..

cd modes
rm -rf redaction-viewer
cp -a ${curr_dir}/../plugins/ohifv3/modes/redaction-viewer redaction-viewer
cd ..

# Install NIfTI Segmentation Overlay Extension
# Standalone overlay loader: fetches .nii.gz from the DICOMweb gateway, aligns
# to the active Cornerstone3D volume, and injects as a labelmap segmentation.
# See nifti_overlay/ and NIFTI_OVERLAY_PLAN.md at the repo root.
# ECG uses OHIF v3.13.2 built-in cornerstone ECG SOP handler (no custom extension).
echo "Installing NIfTI Segmentation Overlay Extension..."
cd extensions
rm -rf nifti-segmentation
cp -a ${curr_dir}/../plugins/ohifv3/extensions/nifti-segmentation nifti-segmentation
cd ..

# Overlay OHIF v3.13.2-compatible package.json files. Stock MONAI Label still
# pins @ohif@3.11 / @cornerstonejs@^3 as dependencies, which nests incompatible
# Cornerstone 3.x under the extension and breaks Rspack exports resolution.
cp ${curr_dir}/../plugins/ohifv3/extensions/monai-label/package.json extensions/monai-label/package.json
cp ${curr_dir}/../plugins/ohifv3/modes/monai-label/package.json modes/monai-label/package.json

# Apply extensions patch to register monai-label, image-redactor,
# and nifti-segmentation in pluginConfig.json
echo "Applying extensions patch (registers monai-label, image-redactor, nifti-segmentation)..."
git apply ${curr_dir}/../plugins/ohifv3/extensions.patch

cp ${curr_dir}/../plugins/ohifv3/config/databricks.js platform/app/public/config/databricks.js

#copy Databricks Pixels integration
echo "Installing Databricks Integration"
mkdir ./extensions/default/src/DatabricksPixelsDicom/
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/index.js ./extensions/default/src/DatabricksPixelsDicom/index.js
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/utils.js ./extensions/default/src/DatabricksPixelsDicom/utils.js
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/fixMultipart.ts ./extensions/default/src/DatabricksPixelsDicom/fixMultipart.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/StaticWadoClient.ts ./extensions/default/src/DatabricksPixelsDicom/StaticWadoClient.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/findIndexOfString.ts ./extensions/default/src/DatabricksPixelsDicom/findIndexOfString.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/getDataSourcesModule.js ./extensions/default/src/getDataSourcesModule.js
cp ${curr_dir}/../plugins/ohifv3/extensions/cornerstone-dicom-seg/src/commandsModule.ts ./extensions/cornerstone-dicom-seg/src/commandsModule.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/dicom-microscopy/src/utils/dicomWebClient.ts ./extensions/dicom-microscopy/src/utils/dicomWebClient.ts
cp ${curr_dir}/../plugins/ohifv3/extensions/default/src/DatabricksPixelsDicom/multiframeImageLoader.js ./extensions/default/src/DatabricksPixelsDicom/multiframeImageLoader.js

# Copy new files and apply Viewers patches for VLM Analyzer
cp ${curr_dir}/../plugins/ohifv3/extensions/cornerstone/src/utils/CornerstoneVLMViewportForm.tsx extensions/cornerstone/src/utils/CornerstoneVLMViewportForm.tsx
cp ${curr_dir}/../plugins/ohifv3/platform/ui-next/src/components/Icons/Sources/MagicWandIcon.tsx platform/ui-next/src/components/Icons/Sources/MagicWandIcon.tsx
cp ${curr_dir}/../plugins/ohifv3/platform/ui-next/src/components/Icons/Sources/NiftiOverlayIcon.tsx platform/ui-next/src/components/Icons/Sources/NiftiOverlayIcon.tsx
 
git apply --reject --whitespace=fix ${curr_dir}/../viewers_extensions_cornerstone_src_commandsModule.ts.patch
git apply --reject --whitespace=fix ${curr_dir}/../viewers_extensions_cornerstone_src_index.tsx.patch
# VLM Analyzer toolbar button + primary section entry. In OHIF v3.13.2
# toolbar defs live in the cornerstone extension customization pack
# (modes/basic no longer ships toolbarButtons.ts).
git apply --reject --whitespace=fix ${curr_dir}/../viewers_extensions_cornerstone_src_customizations_toolbarButtonsCustomization.ts.vlm.patch
git apply --reject --whitespace=fix ${curr_dir}/../viewers_platform_ui-next_src_components_Icons_Icons.tsx.patch

# NIfTI Segmentation Overlay panel wiring.
# - basic mode: registers `@ohif/extension-nifti-segmentation` in
#   extensionDependencies and appends the `niftiOverlayPanel` to the basic
#   layout's rightPanels.
# - longitudinal mode: appends the panel to longitudinal's overridden
#   rightPanels (extensionDependencies inherits from basic via spread).
# - segmentation mode: appends the panel to the dedicated segmentation
#   editor mode's rightPanels (alongside the labelmap + contour panels) so
#   loaded NIfTI overlays can be edited with the mode's brush / eraser /
#   threshold tools. Pulls the panel id from `@ohif/mode-basic` via the
#   `niftiSegmentation` export added by the basic-mode patch above, so this
#   patch must run AFTER the basic-mode patch.
# See nifti_overlay/ and NIFTI_OVERLAY_PLAN.md (Step 10) at the repo root.
git apply --reject --whitespace=fix ${curr_dir}/../viewers_modes_basic_src_index.tsx.nifti.patch
git apply --reject --whitespace=fix ${curr_dir}/../viewers_modes_longitudinal_src_index.ts.nifti.patch
git apply --reject --whitespace=fix ${curr_dir}/../viewers_modes_segmentation_src_index.tsx.nifti.patch


export COREPACK_ENABLE_DOWNLOAD_PROMPT=0

# OHIF v3.13.2 requires Node >= 24 and pnpm >= 11.
NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)"
if [ "${NODE_MAJOR}" -lt 24 ]; then
    echo "ERROR: OHIF v3.13.2 requires Node.js >= 24 (found $(node -v 2>/dev/null || echo 'none'))."
    echo "       e.g.: nvm install 24 && nvm use 24"
    exit 1
fi
if ! command -v pnpm >/dev/null 2>&1; then
    echo "Enabling pnpm via corepack..."
    corepack enable
    corepack prepare pnpm@11.5.2 --activate
fi

# Skip NPM registry override for local builds and for public CI (GitHub
# Actions etc.) - the Databricks npm-proxy is only reachable from inside
# the Databricks network. To force a specific registry in any context,
# set NPM_REGISTRY=<url> explicitly before invoking this script.
if [ "$local" = "FALSE" ] || [ -n "$GITHUB_ACTIONS" ] || [ "$CI" = "true" ] && [ -z "$NPM_REGISTRY" ]; then
    echo "Skipping NPM registry override (local/CI build, no NPM_REGISTRY set)."
else
    NPM_REGISTRY="${NPM_REGISTRY:-https://npm-proxy.cloud.databricks.com}"
    export COREPACK_NPM_REGISTRY="${NPM_REGISTRY}"

    echo "Rewriting pnpm-lock.yaml tarball URLs to use ${NPM_REGISTRY}..."
    sed -i.bak \
        -e "s|https://registry\.npmjs\.org|${NPM_REGISTRY}|g" \
        -e "s|https://registry\.yarnpkg\.com|${NPM_REGISTRY}|g" \
        pnpm-lock.yaml && rm pnpm-lock.yaml.bak

    pnpm config set registry "${NPM_REGISTRY}/"
fi

# pnpm 11+ rejects `pnpm config set network-timeout` (not a global config key).
# The supported setting is `fetchTimeout`, set in the workspace file instead.
grep -q '^fetchTimeout:' pnpm-workspace.yaml || printf '\nfetchTimeout: 600000\n' >> pnpm-workspace.yaml
# Custom extensions/modes are copied into the workspace before install.
# Upstream sets frozenLockfile: true, which would skip their deps
# (nrrd-js, nifti-reader-js, …) — disable it for this build.
sed -i.bak 's/^frozenLockfile: true$/frozenLockfile: false/' pnpm-workspace.yaml && rm -f pnpm-workspace.yaml.bak
pnpm install
# Newly copied workspace packages can be missed by a no-op install against an
# existing node_modules; force their dependency trees to link.
pnpm install \
    --filter @ohif/extension-monai-label... \
    --filter @ohif/extension-nifti-segmentation... \
    --filter @ohif/extension-image-redactor... \
    --filter @ohif/mode-monai-label... \
    --filter @ohif/mode-redaction-viewer...
pnpm run cli list

# v3.13.2 writePluginImportsFile.js already prefixes PUBLIC_URL with "." for
# browserImportFunction; the old sed is no longer needed.

APP_CONFIG=config/databricks.js PUBLIC_URL=./ QUICK_BUILD=true pnpm run build

if [ ! -d platform/app/dist ]; then
    echo "ERROR: OHIF build did not produce platform/app/dist — aborting."
    exit 1
fi

rm -rf ${install_dir}
mkdir -p "$(dirname "${install_dir}")"
cp -r platform/app/dist/ ${install_dir}
echo "Copied OHIF to ${install_dir}"

if [ "$local" = "TRUE" ]; then
    echo "Building OHIF locally"
else
    rm -rf Viewers
    find .  -type d -name "node_modules" -exec rm -rf "{}" +
fi

echo "Patching index.html"
cd ${install_dir}
sed -i.bak 's/app-config.js/app-config-custom.js/g' index.html && rm index.html.bak
echo "OHIF for databricks created"

echo ""
echo "✅ Image Redactor Extension successfully integrated!"
echo "   - Extension: image-redactor"
echo "   - Mode: redaction-viewer" 
echo "   - Author: Emanuele Rinaldi <emanuele.rinaldi@databricks.com>"
echo "   - License: Databricks License Agreement"
echo ""
echo "🎯 Features available:"
echo "   - Manual rectangle drawing for redaction areas"
echo "   - Multiple area selection before applying redaction"
echo "   - Pixel burning (permanent redaction)"
echo "   - Undo functionality"
echo "   - Export redacted images as PNG"
echo ""
echo "📖 Usage: Select 'Redaction Viewer' mode in OHIF to access redaction tools"
echo ""

cd ${curr_dir}
